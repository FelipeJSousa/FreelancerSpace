﻿using Repositorio.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace Repositorio.Repositorios
{
    public class RamoAtividadesRepository : BaseRepository<RamoAtividade>
    {
    }
}
